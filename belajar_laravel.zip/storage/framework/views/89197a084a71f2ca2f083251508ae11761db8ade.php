<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('judul', 'Donasi Saya'); ?>
<?php $__env->startSection('donasi_saya_nav', 'active-nav'); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">

	<div class="col-md-8" >
		<?php if($donasi_saya->count() > 0): ?> <!-- jika ada data ini ditampilkan, jika data kosong tidak tampil -->
		<form action="/dashboard/cari_donasi" method="get"> <!-- yg action ada di controller, pakai method get -->
			<div class="input-group mb-3">
			  <input type="text" class="form-control" name="cari" placeholder="Cari Donasi" aria-describedby="basic-addon2"> <!-- input text dengan nama cari -->
			  <div class="input-group-append">
			    <button class="btn btn-outline-secondary" type="submit">Cari</button>
			  </div>
			</div>
		</form>


		<?php $__currentLoopData = $donasi_saya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- foreach data pencarian -->
		<div class="row" style="margin-bottom: 10px">
			<div class="col-md-3">
				<div class="box-img" style="background-repeat: no-repeat;background-position: center center;background-size: cover;padding-bottom: 56%;min-width: 100%;background-image: url( <?php echo e(asset('assets/img/galang_dana/'.$donasi->gambar )); ?> );">
				</div>
			</div>
			<div class="col-md-9" style="padding: 0">
				<h5><?php echo e($donasi->judul); ?></h5>
				<p style="font-size: 12px;display: unset"><?php echo e($donasi->tgl_donasi); ?> | Rp. <?php echo e(number_format($donasi->jumlah_dana)); ?> </p>
				<?php if($donasi->status_dana == "sukses"): ?> 
				<p style="background: green;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">SUKSES</p>
				<?php elseif($donasi->status_dana == "pending"): ?> 
				<p style="background: #ffc800;padding: 5px;display: unset;border-radius: 5px;color: black;font-size: 10px">PENDING</p>
				 <button class="btn btn-success btn-sm" onclick="snap.pay('<?php echo e($donasi->snap_token); ?>')">Complete Payment</button>
				<?php else: ?> 
				<p style="background: red;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">GAGAL</p>
				<?php endif; ?>

			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php echo e($donasi_saya->links()); ?> <!-- ini untuk fungsi pagination -->

		<?php else: ?> <!-- jika belum ada data di database -->
			<center>
				<p style="width: 100%;background: #fff6ed;text-align: center;padding: 5px;margin-bottom: 10px">Anda belum melakukan Donasi</p>
				<a href="/akun" class="tombol-n1 text-center">Mari Donasi</a>
			</center>
		<?php endif; ?>

	</div>

	<div class="col-md-4" >
		<div style="background: #ff9e3b17;padding: 10px">
			<?php $__currentLoopData = $detail_donasi_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- foreach data detail ( abaikan ) -->
			<p>Total Donasi</p>
			<p style="font-weight: bolder;"><?php echo e($detail->jumlah_donasi); ?></p>
			<hr>
			<p>Total Dana Donasi</p>
			<p style="font-weight: bolder;">Rp. <?php echo e(number_format($detail->jumlah_dana)); ?></p>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</div>	
	</div>
</div>

<!-- fungsi midtrans -->
<script src="<?php echo e(!config('services.midtrans.isProduction') ? 'https://app.sandbox.midtrans.com/snap/snap.js' : 'https://app.midtrans.com/snap/snap.js'); ?>" data-client-key="<?php echo e(config('services.midtrans.clientKey')); ?>"></script>
    <script>
    function submitForm() {
        // Kirim request ajax
        $.post("<?php echo e(route('donation.store')); ?>",
        {
            _method: 'POST',
            _token: '<?php echo e(csrf_token()); ?>',
            jumlah_dana: $('input#jumlah_dana').val(),
            judul: $('input#judul').val(),
            id_galang_dana: $('input#id_galang_dana').val(),
            anonim: $('checkbox#anonim').val(),
            komentar: $('textarea#komentar').val(),


        },


        function (data, status) {
            snap.pay(data.snap_token, {
                // Optional
                onSuccess: function (result) {
                    location.reload();
                },
                // Optional
                onPending: function (result) {
                    location.reload();
                },
                // Optional
                onError: function (result) {
                    location.reload();
                }
            });
        });


        return false;
    }


    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_user/donasi_saya.blade.php ENDPATH**/ ?>