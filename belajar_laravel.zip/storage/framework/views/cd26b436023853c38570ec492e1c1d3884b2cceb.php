<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('judul', 'Donasi'); ?>
<?php $__env->startSection('donasi_nav', 'active-nav'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-8" >
		<form action="/dashboard_admin/cari_donasi" method="get"> 
			<div class="input-group mb-3">
			  <input type="text" class="form-control" name="cari" placeholder="Cari Donasi" aria-describedby="basic-addon2"> 
			  <div class="input-group-append">
			    <button class="btn btn-outline-secondary" type="submit">Cari</button>
			  </div>
			</div>
		</form>


		<?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="row" style="margin-bottom: 10px">
			<div class="col-md-3">
				<div class="box-img" style="background-repeat: no-repeat;background-position: center center;background-size: cover;padding-bottom: 56%;min-width: 100%;background-image: url( <?php echo e(asset('assets/img/galang_dana/'.$data_donasi->gambar )); ?> );">
				</div>
			</div>
			<div class="col-md-9" style="padding: 0">
				<h5><?php echo e($data_donasi->judul); ?></h5>
				<p style="font-size: 12px;display: unset"><?php echo e($data_donasi->tgl_donasi); ?> | Rp. <?php echo e(number_format($data_donasi->jumlah_dana)); ?> | User : <?php echo e($data_donasi->id_user); ?> </p>
				<?php if($data_donasi->status_dana == "sukses"): ?> 
				<p style="background: green;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">SUKSES</p>
				<?php elseif($data_donasi->status_dana == "pending"): ?> 
				<p style="background: #ffc800;padding: 5px;display: unset;border-radius: 5px;color: black;font-size: 10px">PENDING</p>
				<?php else: ?> 
				<p style="background: red;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">GAGAL</p>
				<?php endif; ?>

			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($donasi->links()); ?> <!-- ini untuk fungsi pagination -->
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_admin/donasi.blade.php ENDPATH**/ ?>