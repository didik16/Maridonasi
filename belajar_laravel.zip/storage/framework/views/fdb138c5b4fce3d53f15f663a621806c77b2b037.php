<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('judul', 'Galang Dana'); ?>
<?php $__env->startSection('galang_dana_nav', 'active-nav'); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/js/tempusdominus-bootstrap-4.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/css/tempusdominus-bootstrap-4.min.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

<div class="col-md-12" >
  <form action="/dashboard_admin/cari_galang_dana" method="get">
    <div class="row">
      <div class="form-group col-md-5">
        <div class="input-group date" id="datetimepicker4" data-target-input="nearest">
            <input type="text" class="form-control datetimepicker-input" data-target="#datetimepicker4"/>
            <div class="input-group-append" data-target="#datetimepicker4" data-toggle="datetimepicker">
                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
      <div class="form-group col-md-7">
        <div class="input-group">
          <input type="text" class=" form-control" name="cari" placeholder="Cari Galang Dana" aria-describedby="basic-addon2">
          <div class="input-group-append">
            <button class="btn btn-outline-secondary" type="submit">Cari</button>
          </div>
        </div>
      </div>
  </div>
</form>


     <?php $__currentLoopData = $galang_dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="row" style="margin-bottom: 10px">
      <div class="col-md-3">
       <div class="box-img" style="background-repeat: no-repeat;background-position: center center;background-size: cover;padding-bottom: 56%;min-width: 100%;background-image: url( <?php echo e(asset('assets/img/galang_dana/'.$galang->gambar )); ?> );">
       </div>
      </div>
      <div class="col-md-9" style="padding: 0">
       <h5><?php echo e($galang->judul); ?></h5>
       <p style="font-size: 12px;display: unset"><?php echo e($galang->tgl_galang_dana); ?> | Rp. <?php echo e(number_format($galang->jumlah_dana)); ?> </p>
       <?php if($galang->status == "YES"): ?> 
       <p style="background: green;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">DITERIMA</p>
       <?php elseif($galang->status == "CEK"): ?> 
       <p style="background: orange;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">DIPROSES</p>
       <?php else: ?>
       <p style="background: red;padding: 5px;display: unset;border-radius: 5px;color: white;font-size: 10px">DITOLAK</p>
       <?php endif; ?>
      </div>
     </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     <?php echo e($galang_dana->links()); ?>


   </div>

 
   </div>

<script type="text/javascript">

    $('#datetimepicker4').datetimepicker({

        

    }); 

</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_admin/galang_dana.blade.php ENDPATH**/ ?>