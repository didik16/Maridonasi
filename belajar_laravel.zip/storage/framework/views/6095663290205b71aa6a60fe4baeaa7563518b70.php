<?php $__env->startSection('title', 'Transaksi Saldo'); ?>

<?php $__env->startSection('judul', 'Transaksi Saldo'); ?>
<?php $__env->startSection('backend_admin', 'active-nav'); ?>
<?php $__env->startSection('script'); ?>


  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.20/r-2.2.3/sp-1.0.1/datatables.min.css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12" >
		<table class="table table-bordered" id="saldo">
       <thead>
          <tr>
             <th>Id</th>
             <th>User</th>
             <th>Tanggal Transaksi</th>
             <th>Jumlah</th>
          </tr>
       </thead>
      <tbody>
        <?php $__currentLoopData = $saldo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($p->id_saldo); ?></td>
          <td><?php echo e($p->name); ?></td>
          <td><?php echo e($p->created_at); ?></td>
          <td><?php echo e('Rp. '.number_format($p->jumlah)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
       <tfoot>
          <tr>
             <th>Id</th>
             <th>User</th>
             <th>Tanggal Transaksi</th>
             <th>Jumlah</th>
          </tr>
       </tfoot>
    </table>
  </div>




  <script>
  $(function () {
    
    $('#saldo').DataTable({
    });
  });
</script>

  <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.20/r-2.2.3/sp-1.0.1/datatables.min.js"></script>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_admin/transaksi_saldo.blade.php ENDPATH**/ ?>