


<p>Hallo, <?php echo e(Auth::user()->name); ?>. Apakabar?</p>

  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend/index.blade.php ENDPATH**/ ?>