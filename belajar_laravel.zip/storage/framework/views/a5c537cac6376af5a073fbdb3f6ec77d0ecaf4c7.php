<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('judul', 'Verifikasi Galang Dana'); ?>
<?php $__env->startSection('galang_dana_nav', 'active-nav'); ?>
<?php $__env->startSection('script'); ?>
<!-- 	<link  href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet">
  <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script> -->

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.20/r-2.2.3/sp-1.0.1/datatables.min.css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12" >
    <hr>
    <a href="/dashboard_admin/galang_dana" class="btn btn-primary">Semua Galang Dana</a>
    <hr>
		<table class="table table-bordered" id="verifikasi">
       <thead>
          <tr>
             <th>Id</th>
             <th>Judul</th>
             <th>Jumlah Dana</th>
             <th>Status</th>
             <th>Verifikasi</th>
          </tr>
       </thead>
      <tbody>
        <?php $__currentLoopData = $galang_dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($p->id_galang_dana); ?></td>
          <td><?php echo e($p->judul); ?></td>
          <td><?php echo e('Rp. '.number_format($p->jumlah_dana)); ?></td>
          <td><center><p style="background: yellow;font-weight: bold;"><?php echo e($p->status); ?></p></center></td>
          <td>
            <center><a href='#' class='btn btn-default btn-small'><i class="fas fa-edit"></i></a></center>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
       <tfoot>
          <tr>
             <th>Id</th>
             <th>Judul</th>
             <th>Jumlah Dana</th>
             <th>Status</th>
             <th>Verifikasi</th>
          </tr>
       </tfoot>
    </table>
  </div>

<!-- Modal -->

   <!-- <script>
   $(document).ready( function () {
    var table = $('#verifikasi').DataTable({
           processing: true,
           serverSide: true,
           ajax: "/dashboard_admin/data_verifikasi_galang_dana",
           columns: [
                    { data: 'id_galang_dana', name: 'id_galang_dana' },
                    { data: 'judul', name: 'judul' },
                    { data: 'jumlah_dana', name: 'jumlah_dana' },
                    { data: 'status', name: 'status', render: $.fn.dataTable.render.number( ',', '.', 2, '$' ) },
                    { defaultContent: '<a href=""><button>Detail</button></a>' },
                 ]
        });
          $('#verifikasi tbody').on( 'click', 'button', function () {
        var data = table.row( $(this).parents('tr') ).data();
        alert( data[1] +"'s salary is: "+ data[2] );
    } );

     });
  </script> -->


  <script>
  $(function () {
    
    $('#verifikasi').DataTable({
/*      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,*/
    });
  });
</script>

  <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.20/r-2.2.3/sp-1.0.1/datatables.min.js"></script>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_admin/verifikasi_galang_dana.blade.php ENDPATH**/ ?>