<?php $__env->startSection('title', 'Pencairan Dana'); ?>

<?php $__env->startSection('judul', 'Pencairan Dana'); ?>
<?php $__env->startSection('pencairan_nav', 'active-nav'); ?>
<?php $__env->startSection('script'); ?>


  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.20/r-2.2.3/sp-1.0.1/datatables.min.css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12" >
    <hr>
    <a href="#" class="btn btn-primary">Verifikasi Pencairan</a>
    <hr>
		<table class="table table-bordered" id="saldo">
       <thead>
          <tr>
             <th>Id</th>
             <th>Id Galang</th>
             <th>Tgl</th>
             <th>User</th>
             <th>Jumlah</th>
             <th>Keterangan</th>
             <th>Bukti</th>
             <th>Status</th>
          </tr>
       </thead>
      <tbody>
        <?php $__currentLoopData = $pencairan_dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($p->id); ?></td>
          <td><?php echo e($p->id_galang_dana); ?></td>
          <td><?php echo e($p->created_at); ?></td>
          <td><?php echo e($p->id_user); ?></td>
          <td><?php echo e('Rp. '.number_format($p->jumlah)); ?></td>
          <td><?php echo e($p->keterangan); ?></td>
          <td><?php echo e($p->bukti); ?></td>
          <td><?php echo e($p->status); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
       <tfoot>
          <tr>
             <th>Id</th>
             <th>Id Galang</th>
             <th>Tgl</th>
             <th>User</th>
             <th>Jumlah</th>
             <th>Keterangan</th>
             <th>Bukti</th>
             <th>Status</th>
          </tr>
       </tfoot>
    </table>
  </div>




  <script>
  $(function () {
    
    $('#saldo').DataTable({
    });
  });
</script>

  <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.20/r-2.2.3/sp-1.0.1/datatables.min.js"></script>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_admin/pencairan_dana.blade.php ENDPATH**/ ?>