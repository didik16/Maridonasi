<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('judul', 'Dashboard'); ?>
<?php $__env->startSection('dashboard_nav', 'active-nav'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<?php $__currentLoopData = $detail_donasi_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-4 col-xs-6" style="padding: 5px"> 
		<div class="small-box bg-yellow">
			<div class="inner">
	 			<h3 style="color: white"><?php echo e($detail->jumlah_donasi); ?></h3>
				<p style="color: white">Total Donasi</p>
			</div>
			<div class="icon">
				<i class="fas fa-hand-holding-heart" aria-hidden="true"></i>
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-xs-6" style="padding: 5px">
		<div class="small-box bg-aqua">
			<div class="inner">
	 			<h3 style="color: white"><?php echo e('Rp.' .number_format($detail->jumlah_dana)); ?></h3>
				<p style="color: white">Total Didonasikan</p>
			</div>
			<div class="icon">
				<i class="fas fa-money-bill-wave"></i>
			</div>
		</div>
	</div>
		<div class="col-lg-4 col-xs-6" style="padding: 5px">
		<div class="small-box bg-red1">
			<div class="inner">
	 			<h3 style="color: white"><?php echo e($detail->jumlah_galang); ?></h3>
				<p style="color: white">Total Galang Dana</p>
			</div>
			<div class="icon">
				<i class="fas fa-child" aria-hidden="true"></i>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="panel">
	<div id="chartDashboard" style="width:100%; height:400px;"></div>
</div>

<?php $__env->startSection('script'); ?>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function () {
        var myChart = Highcharts.chart('chartDashboard', {
            chart: {
                type: 'line'
            },
            title: {
                text: 'Data Donasi Bulan Ini'
            },
            xAxis: {
                categories: <?php echo json_encode($tanggal); ?>,
            },
            yAxis: {
                title: {
                    text: 'Data Donasi'
                }
            },
            series: [{
                name: 'Total Donasi',
                data: <?php echo json_encode($dana); ?>

            }]
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_user/dashboard.blade.php ENDPATH**/ ?>