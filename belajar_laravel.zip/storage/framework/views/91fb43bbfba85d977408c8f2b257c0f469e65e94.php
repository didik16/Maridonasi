<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	a {
		color: black;
	}
</style>
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5df2d47d02b11200120138e0' async='async'></script>


<div class="container">
	<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<img src="<?php echo e(asset('assets/img/galang_dana/'.$detail->gambar)); ?>" width="100%" style="margin-bottom: 25px">
	
	<div class="row">
		<div class="col-md-8">
			<H1><?php echo e($detail->judul); ?></H1>

			<ul class="nav nav-tabs nav-justified" role="tablist">
			  <li class="nav-item">
			    <a class="nav-link active" href="#deskripsi" role="tab" data-toggle="tab">Deskripsi</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link" href="#perkembangan" role="tab" data-toggle="tab">Perkembangan</a>
			  </li>
			</ul>

			<!-- Tab panes -->
			<div class="tab-content">
			  <div role="tabpanel" class="tab-pane  active" id="deskripsi" style="margin: 15px 0px">
			  	<?php echo $detail->deskripsi ?>

			  	<br>

			  </div>
			  
			  <div role="tabpanel" class="tab-pane " id="perkembangan">
			  	<ul style="margin-top: 10px;">
			  		<hr>
			  		<?php $__currentLoopData = $perkembangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  		<li>
			  			<p style="font-weight: bold"><?php echo e($p->tanggal); ?></p>
			  			<p><?php echo $p->keterangan ?></p>
			  			<hr>
			  		</li>
			  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  	</ul>
			  </div>
			  
			</div>
		</div> <!-- Tutup Col-MD-8 -->

		<div class="col-md-4">
			<div class="row" style="margin-bottom: 15px">
				<div class="col-md-3 col-3">
					<img src="https://images.jg-cdn.com/image/8e00f08f-7572-4f7d-a623-6e3741b0659c.jpg?template=size75x75face" style="border-radius: 50%;width: 100%">
				</div>
				<div class="col-md-9 col-9" style="padding : 0">
					<h4 style="font-weight: bolder;">Didik Ariyana</h4>
				</div>
			</div>



			<div class="row" style="margin-bottom: 10px">
				<div class="col-md-8">
					<p style="font-weight: bold;font-size: 18px;color: #fd3300"><?php echo e('Rp. '. number_format($detail->terkumpul)); ?></p>
					<p style="font-size: 12px">Dari Rp. <?php echo e(number_format($detail->jumlah_dana)); ?> </p>
				</div>
				<div class="col-md-4" style="text-align: right;">
					<p style="font-weight: bold;font-size: 15px">
						<?php if($detail->sisa_hari >0 ){ 
							echo $detail->sisa_hari;
						}else{
							echo '0';} 
						?> Hari</p>
					<p style="font-size: 12px">Sisa Hari</p>
				</div>
			</div>

			<div class="progress" style="margin-bottom: 10px;height: 1rem">
				
					<?php if(floor($detail->terkumpul / $detail->jumlah_dana*100) >=100): ?>
						<div class="progress-bar" role="progressbar" style="width: <?php echo e(($detail->terkumpul / $detail->jumlah_dana*100)); ?>%;padding:0px 5px;background: #ff2525" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">
					 	100% 
					 </div>
					<?php else: ?>
						<div class="progress-bar" role="progressbar" style="width: <?php echo e(($detail->terkumpul / $detail->jumlah_dana*100)); ?>%;padding:0px 5px;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">
						<?= floor($detail->terkumpul / $detail->jumlah_dana*100).'%' ?>
					 </div>
					<?php endif; ?>

				
			</div>
			<a href="<?php echo e('/donasi/'.$detail->id_galang_dana.'/'.$detail->slug); ?>" class="tombol-n1" style="margin: 0 auto;display: table;font-size: 20px;width: 100%;text-align: center;">DONASI</a>

			<div class="row" style="margin-top: 15px">
				<div class="col-md-7">
					<p style="font-size: 20px;font-weight: bold;">Donatur</p>
				</div>
				<div class="col-md-5" style="text-align: right;">
					<?php $__currentLoopData = $jml_donatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jml_donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<p><?php echo e($jml_donatur->jml); ?> Orang</p>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

			<?php $__currentLoopData = $donatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php if($donatur->anonim != "Y") { ?>

				<div class="row" style="margin: 15px 0px;background: #f5f3f3;padding: 10px 0px;">
					<div class="col-md-3">
						<?php if($donatur->foto == NULL){ ?>
							<img src="<?php echo e(asset('assets/img/user/user.webp')); ?>" style="border-radius: 50%;width: 100%">
						<?php } else { ?>
							<img src="<?php echo e(asset('assets/img/user/'.$donatur->foto)); ?>" style="border-radius: 50%;width: 100%">
						<?php } ?>
					</div>
					<div class="col-md-6" style="padding: 0">
						<h5 style="font-weight: bolder;margin: 0"><?php echo e(ucwords($donatur->name)); ?></h5>
						<p style="font-size: 12px">Rp. <?php echo e(number_format($donatur->jumlah_dana)); ?></p>
						<p style="font-size: 10px"><?php echo e($donatur->komentar); ?></p>
					</div>
					<div class="col-md-3" style="text-align: right;">
						<p style="font-size: 10px"><?php echo e($donatur->tgl_donasi); ?></p>
					</div>
				</div>

			<?php } else { ?>
				<div class="row" style="margin: 15px 0px;background: #f5f3f3;padding: 10px 0px;">
					<div class="col-md-3">
						<img src="<?php echo e(asset('assets/img/user/user.webp')); ?>" style="border-radius: 50%;width: 100%">
					</div>
					<div class="col-md-6" style="padding: 0">
						<h5 style="font-weight: bolder;margin: 0">Anonim</h5>
						<p style="font-size: 12px">Rp. <?php echo e(number_format($donatur->jumlah_dana)); ?></p>
						<p style="font-size: 10px"><?php echo e($donatur->komentar); ?></p>
					</div>
					<div class="col-md-3" style="text-align: right;">
						<p style="font-size: 10px"><?php echo e($donatur->tgl_donasi); ?></p>
					</div>
				</div>

			<?php } ?>


			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>



	

<!-- <div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 75%"></div>
</div> -->




	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- <script>
  $(document).ready(function() {
    $('.imgSmall img').click(function(event) {
    	console.log("Hai")
      var id = $(this).data('id');
      var src = $(this).attr('src');
      var img = $('#imgBig img');

      img.fadeOut('fast', function() {
        $(this).attr({src: src,});
        $(this).fadeIn('fast');
      });
    });
  });
</script> -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/galang_dana/detail.blade.php ENDPATH**/ ?>