<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
  p {
    margin: 0
  }
</style>

 <div class="container">
 <?php echo e(csrf_field()); ?>

     <div id="post_data" style="margin: 30px 0px"></div>
   </div>

<script>
$(document).ready(function(){
 
 var _token = $('input[name="_token"]').val();

 load_data('', _token);

 function load_data(id="", _token)
 {
  $.ajax({
   url:"<?php echo e(route('loadmore.load_data')); ?>",
   method:"POST",
   data:{id:id, _token:_token},
   success:function(data)
   {
    $('#load_more_button').remove();
    $('#post_data').append(data);
   }
  })
 }

 $(document).on('click', '#load_more_button', function(){
  var id = $(this).data('id');
  $('#load_more_button').html('<b>Loading...</b>');
  load_data(id, _token);
 });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/galang_dana/load_more.blade.php ENDPATH**/ ?>