<?php $__env->startSection('title', 'Galang Dana'); ?>

<?php $__env->startSection('judul', 'Dashboard Admin'); ?>
<?php $__env->startSection('dashboard_nav', 'active-nav'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-4 col-xs-6" style="padding: 5px"> 
		<div class="small-box bg-yellow">
			<div class="inner">
	 			<h3 style="color: white"><?php echo e($detail->jumlah_donatur); ?></h3>
				<p style="color: white">Total Donatur</p>
			</div>
			<div class="icon">
				<i class="fas fa-hand-holding-heart" aria-hidden="true"></i>
			</div>
		</div>
	</div>
	<div class="col-lg-4 col-xs-6" style="padding: 5px">
		<div class="small-box bg-aqua">
			<div class="inner">
	 			<h3 style="color: white"><?php echo e('Rp.' .number_format($detail->total_dana_terkumpul)); ?></h3>
				<p style="color: white">Total Didonasikan</p>
			</div>
			<div class="icon">
				<i class="fas fa-money-bill-wave"></i>
			</div>
		</div>
	</div>
		<div class="col-lg-4 col-xs-6" style="padding: 5px">
		<div class="small-box bg-red1">
			<div class="inner">
	 			<h3 style="color: white"><?php echo e($detail->jumlah_galang_dana); ?></h3>
				<p style="color: white">Total Galang Dana</p>
			</div>
			<div class="icon">
				<i class="fas fa-child" aria-hidden="true"></i>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/backend_admin/dashboard_admin.blade.php ENDPATH**/ ?>