<!DOCTYPE html>
<html>
<head>
	<title>MariDonasi.com - <?php echo $__env->yieldContent('title'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom/style-footer.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom/style-header.css')); ?>">
	
	<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/icon/favicon.png')); ?>"/>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
	<script src="https://kit.fontawesome.com/142f9408d2.js" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">

	<?php echo $__env->yieldContent('script'); ?>

<?php $parameters = \Request::segment(1);
  if($parameters=="campaign"){
   ?>
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom/style-home.css')); ?>">
  <?php } ?>


</head>
<body>


<style type="text/css">
	p{
		margin:0;
	}
</style>

<div class="preloader">
  <div class="loading">
    <img src="<?php echo e(asset('assets/img/icon/loading.gif')); ?>" width="100%">
  </div>
</div>

	<!-- Navbar -->
	<?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
		<?php echo $__env->yieldContent('content'); ?>


	<!-- footer -->
	<?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

<?php if(Session::has('message')): ?>
<script type="text/javascript">
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;

        case 'warning':
            toastr.warning("<?php echo e(Session::get('message')); ?>");
            break;

        case 'success':
            toastr.success("<?php echo e(Session::get('message')); ?>");
            break;

        case 'error':
            toastr.error("<?php echo e(Session::get('message')); ?>");
            break;
    }
    </script>
  <?php endif; ?>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/58b2484078d62074c0942108/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
$(document).ready(function(){
$(".preloader").fadeOut();
})
</script>






</body>
</html><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/layout/app.blade.php ENDPATH**/ ?>