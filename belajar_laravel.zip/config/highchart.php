<?php

return [
    'highchart_js'      => true,
    'series_label_js'   => true,
    'exporting_js'      => true,
    'export_data_js'    => true,
];
